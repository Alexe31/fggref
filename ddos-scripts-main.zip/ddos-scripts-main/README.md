#### ddos-scripts
+ ICMP flooder 
+ tcp flooder 
+ udp flooder 
+ http flooder 
+ https flooder

`and etc by MJi Zero `
-------
+  run BotNet.py
   - python BotNet.py
-------
###### username [\password\] panel botnet :
`admin, $2a$08$QfkvbA/w73zbr9YfZR.p5uK7bvUnApFawguHSBxq7ualsjVywFzru`

###### token : 
`3970e89ef456dead259396be26e32d52aee74992196ab026352f2e17c5c02392a50a3299bce3108daf75c6c274d63bf5e1db3adc3277c6bf78337fbdab7b572e292b63a94f497d331eac0c18dd5fceeee998335ebc4ca4b0f228b276d6de6f8004fc21425ec75d058c15b3d767694098da37ce5965b5948210eb48861fd996431fa1e3171c6262c5757d9d66b500167d64b5d0cafbfea5492471915d32321c83d4a8e81e61d6c8788c3e46cce0fdc6c8889ca780365dd760b73b4081dd5436f3e3cae606e3ecf212e3e24a4a0fc124a72c7c077f6359cf46d3ebf8af146d26058388959ff8903cd9785f5f16c36a47df1f4ecb8087696b7b59c12d7df1a58290`
